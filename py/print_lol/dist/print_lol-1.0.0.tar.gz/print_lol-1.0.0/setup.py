from distutils.core import setup

setup(
	name = 'print_lol',
	version = '1.0.0',
	py_modules = ['print_lol'],
	author = 'asxainaa',
	author_email = 'asxainaa@gmail.com',
	description = 'A simple nested list printer',
)
